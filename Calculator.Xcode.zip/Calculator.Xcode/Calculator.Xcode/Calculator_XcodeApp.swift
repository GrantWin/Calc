//
//  Calculator_XcodeApp.swift
//  Calculator.Xcode
//
//  Created by Timothy Wininger on 4/6/23.
//

import SwiftUI

@main
struct Calculator_XcodeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
